export enum CategoryType {
    "idols and figures", "Wall Sculptures", "Paintings", "Artificial floras"
}
