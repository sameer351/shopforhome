export class Discount {
    id:number;
    status:number;
    email:string;
    coupon:string;

    
}
